/* add.c
 *	Simple program to test whether the systemcall interface works.
 *	
 *	Just do a add syscall that adds two values and returns the result.
 *
 */

#include "syscall.h"
int foo()
{
	while (1)
	return 0;
}

int
main()
{
  int result;
  int t = ThreadFork(foo);
  t = ThreadFork(foo);
  t = ThreadFork(foo);
  t = ThreadFork(foo);
  while (1)
  
  result = Add(42, 23);

  Halt();
  /* not reached */
}
